public class Node {
    public int value;
    public Node next;
    public Node previous;

    public Node(int value) {
        this.value = value;
        this.next = null;
        this.previous = null;
    }
}
