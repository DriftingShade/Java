package com.snosack.daikichipathvariables;

class DaikichipathvariablesApplicationTests {
	public static void main(String[] args) {

	}

}
